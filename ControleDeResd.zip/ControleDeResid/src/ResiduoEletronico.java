/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */



/**
 *
 * @author SAMUEL
 */
public class ResiduoEletronico extends ControleDeResiduo {

    private String nomeEquipamento;
    private int quantE; //quantidade de equipamentos
       
    public ResiduoEletronico() {
        super();
    }

    public ResiduoEletronico (String acondicionamento,double pesoKg,String status,String dataArmazenamento, String areaGeracaoDeResiduo, String turnoDeGeracao,String nomeEquipamento, int quantE) {

        super(acondicionamento, pesoKg, status, dataArmazenamento, areaGeracaoDeResiduo, turnoDeGeracao);
        this. nomeEquipamento = nomeEquipamento;
        this.quantE = quantE;

    }
    
    @Override
    public String toString() {
 
            return String.format("ID: = %d", id) + "\n"+
                   String.format("Nome do Equipamento: = %s", nomeEquipamento)+ "\n"+
                   String.format("Quantidade de Equipamentos: = %s", quantE)+ "\n"+
                   String.format("Acondicionamento: = %s", acondicionamento) + "\n"+
                   String.format("Peso em Kg: = %d", pesoKg) + "\n"+
                   String.format("Status: = %s", status) + "\n"+
                   String.format("Data de armazenamento:  = %s", dataArmazenamento) + "\n"+
                   String.format("Área de geração do resíduo: = %s", areaGeracaoDeResiduo) + "\n"+
                   String.format("Turno de geração:  = %s", turnoDeGeracao);       
    } 

    public String getNomeEquipamento() {
        return nomeEquipamento;
    }

    public void setNomeEquipamento(String nomeEquipamento) {
        this.nomeEquipamento = nomeEquipamento;
    }

    public int getQuantE() {
        return quantE;
    }

    public void setQuantE(int quantE) {
        this.quantE = quantE;
    }
    
    
}
