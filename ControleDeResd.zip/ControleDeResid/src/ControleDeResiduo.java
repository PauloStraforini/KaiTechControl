/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */



/**
 *
 * @author SAMUEL
 */
public class ControleDeResiduo {
    
    protected int id;  // ver necesidade de alterar para private ou protected
    protected String acondicionamento;
    protected double pesoKg;
    protected String status;
    protected String dataArmazenamento;
    protected String areaGeracaoDeResiduo;
    protected String turnoDeGeracao;
   
    public ControleDeResiduo() {
  
        acondicionamento = "";
        pesoKg = 0;
        status = "";
        dataArmazenamento = "";
        areaGeracaoDeResiduo = "";
        turnoDeGeracao= "";

    }

    public ControleDeResiduo (String acondicionamento,double pesoKg,String status,String dataArmazenamento, String areaGeracaoDeResiduo, String turnoDeGeracao) {

        this. acondicionamento = acondicionamento;
        this. pesoKg = pesoKg;
        this. status = status;
        this. dataArmazenamento = dataArmazenamento;
        this. areaGeracaoDeResiduo = areaGeracaoDeResiduo;
        this. turnoDeGeracao = turnoDeGeracao;

    }

    @Override
    public String toString() {

            return String.format("ID: = %d", id) + "\n"+
                   String.format("Acondicionamento: = %s", acondicionamento) + "\n"+
                   String.format("Peso em Kg: = %f", pesoKg) + "\n"+
                   String.format("Status: = %s", status) + "\n"+
                   String.format("Data de armazenamento:  = %s", dataArmazenamento) + "\n"+
                   String.format("Área de geração do resíduo: = %s", areaGeracaoDeResiduo) + "\n"+
                   String.format("Turno de geração:  = %s", turnoDeGeracao);
           
    }
    
// fazer os getts e setts

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAcondicionamento() {
        return acondicionamento;
    }

    public void setAcondicionamento(String acondicionamento) {
        this.acondicionamento = acondicionamento;
    }

    public double getPesoKg() {
        return pesoKg;
    }

    public void setPesoKg(double pesoKg) {
        this.pesoKg = pesoKg;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDataArmazenamento() {
        return dataArmazenamento;
    }

    public void setDataArmazenamento(String dataArmazenamento) {
        this.dataArmazenamento = dataArmazenamento;
    }

    public String getAreaGeracaoDeResiduo() {
        return areaGeracaoDeResiduo;
    }

    public void setAreaGeracaoDeResiduo(String areaGeracaoDeResiduo) {
        this.areaGeracaoDeResiduo = areaGeracaoDeResiduo;
    }

    public String getTurnoDeGeracao() {
        return turnoDeGeracao;
    }

    public void setTurnoDeGeracao(String turnoDeGeracao) {
        this.turnoDeGeracao = turnoDeGeracao;
    }
    
}
