
import java.sql.ResultSet;
import java.util.Scanner;

/**
 *
 * @author SAMUEL
 */
//FALTA CADASTRAR OS ID


public class principal {
    

    private static Scanner scanner;
    private static MySQL bd;
  // ver se não dara problema no switch

    
    
    private static void listarResiduo() {
        //ver como fazer para consultar os dois residuos
        int listResid;
        ResultSet set;
        do{
            
        System.out.println("");
        System.out.println("Selecione o tipo de resíduo que deseja listar: ");
        System.out.println("1- Resíduo Eletronico");
        System.out.println("2- Resíduo Químico");
        listResid = scanner.nextInt();
        scanner.nextLine();
        
        }while(listResid != 1 && listResid != 2);
        
        switch(listResid){
            case 1:
                //falta --------ID-----------         
                String query = "SELECT id,acondicionamento,pesoKg,status,dataArmazenamento, areaGeracaoDeResiduo, turnoDeGeracao,nomeEquipamento, quantE FROM ResiduoEletronico";
                set = bd.select(query);
                ResiduoEletronico residuoE;

                if (set == null) {
                    System.out.println("Nenhum Resíduo cadastrado.");
                } else {
                    try {
                        boolean encontrado = false;
                        while (set.next()) {
                            residuoE = new ResiduoEletronico(
                            set.getInt(1),
                            set.getString(2),
                            set.getDouble(3),
                            set.getString(4),
                            set.getString(5),
                            set.getString(6),
                            set.getString(7),
                            set.getString(8),
                            set.getInt(9)                   
                            );
                    System.out.println(residuoE.toString());
                            encontrado = true;
                        }
                        if (!encontrado) {
                            System.out.println("Nenhum resíduo cadastrado.");
                        }
                    } catch (Exception e) {
                        System.out.printf(
                                "Erro ao ler lista de resíduos: %s\n",
                                e.getMessage());
                    }
                }

                break;
                
            case 2: 
                
                //falta --------ID-----------         
                String querys = "SELECT id,acondicionamento,pesoKg,status,dataArmazenamento, areaGeracaoDeResiduo, turnoDeGeracao,estadoFisico,codigONU FROM ResiduoQuimico";
                set = bd.select(querys);
                ResiduoQuimico residuoQ;

                if (set == null) {
                    System.out.println("Nenhum Resíduo cadastrado.");
                } else {
                    try {
                        boolean encontrado = false;
                        while (set.next()) {
                            residuoQ = new ResiduoQuimico(
                            set.getInt(1),
                            set.getString(2),
                            set.getDouble(3),
                            set.getString(4),
                            set.getString(5),
                            set.getString(6),
                            set.getString(7),
                            set.getString(8),
                            set.getInt(9)                   
                            );
                    System.out.println(residuoQ.toString());
                            encontrado = true;
                        }
                        if (!encontrado) {
                            System.out.println("Nenhum resíduo cadastrado.");
                        }
                    } catch (Exception e) {
                        System.out.printf(
                                "Erro ao ler lista de resíduos: %s\n",
                                e.getMessage());
                    }
                }

                break;
                
                
        }

    }

    private static void consultarResiduo() {
        int consultR;
        
        do{
                        
        System.out.println("");
        System.out.println("Selecione o tipo de resíduo que deseja consultar: ");
        System.out.println("1- Resíduo Eletronico");
        System.out.println("2- Resíduo Químico");
        consultR = scanner.nextInt();
         scanner.nextLine();
        
        }while(consultR != 1 && consultR != 2);
        
        switch(consultR){
            case 1 :
        ResiduoEletronico residE = new ResiduoEletronico();
        
        System.out.print("ID do resíduo: ");
        residE.setId(scanner.nextInt());
        scanner.nextLine();
//--------------------- ADICIONAR O FROM--------------------------
        String query = "SELECT id,acondicionamento,pesoKg,status,dataArmazenamento, areaGeracaoDeResiduo, turnoDeGeracao,nomeEquipamento, quantE"
                + "FROM ResiduoEletronico WHERE id = " + residE.getId();
        ResultSet set = bd.select(query);
        try {
            if (set == null || !set.next()) {
                System.out.println("Resíduo não encontrado.");
            } else {
            residE = new ResiduoEletronico(
                            set.getInt(1),
                            set.getString(2),
                            set.getDouble(3),
                            set.getString(4),
                            set.getString(5),
                            set.getString(6),
                            set.getString(7),
                            set.getString(8),
                            set.getInt(9)                   
                            );
                System.out.println(residE.toString());
            }
        } catch (Exception e) {
            System.out.printf(
                    "Erro ao ler lista de resíduo: %s\n",
                    e.getMessage());
        }
                
                
            break;    
            
            case 2:
                
        ResiduoQuimico residQ = new ResiduoQuimico();
        
        System.out.print("ID do resíduo: ");
        residQ.setId(scanner.nextInt());
        scanner.nextLine();

        String querys = "SELECT id,acondicionamento,pesoKg,status,dataArmazenamento, areaGeracaoDeResiduo, turnoDeGeracao,estadoFisico,codigONU"
        + "FROM ResiduoQuimico WHERE id = " + residQ.getId();
        set = bd.select(querys);//verificar se dara erro com o querys
        try {
            if (set == null || !set.next()) {
                System.out.println("Resíduo não encontrado.");
            } else {
            residQ = new ResiduoQuimico(
                             set.getInt(1),
                            set.getString(2),
                            set.getDouble(3),
                            set.getString(4),
                            set.getString(5),
                            set.getString(6),
                            set.getString(7),
                            set.getString(8),
                            set.getInt(9)                   
                            );
                System.out.println(residE.toString());
            }
        } catch (Exception e) {
            System.out.printf(
                    "Erro ao ler lista de resíduo: %s\n",
                    e.getMessage());
        }
                
            
                
            break;    
        }

    }

    private static void cadastrarResiduo() {
        int tipo;
        
        do{
            
        System.out.println("");
        System.out.println("Selecione o tipo: ");
        System.out.println("1- Resíduo Eletronico");
        System.out.println("2- Resíduo Químico");
        tipo = scanner.nextInt();
        scanner.nextLine();
        
        }while(tipo != 1 && tipo != 2);
        
        switch(tipo){
            case 1:
                
        ResiduoEletronico  resid = new ResiduoEletronico();
        
        System.out.print("Nome do equipamento: ");
        resid.setNomeEquipamento(scanner.nextLine());
        System.out.print("Quantidade do equipamento: ");
        resid.setQuantE(scanner.nextInt());
        scanner.nextLine();
        System.out.print("Acondicionamento: ");
        resid.setAcondicionamento(scanner.nextLine());
        System.out.print("Peso em Kg: ");
        resid.setPesoKg(scanner.nextDouble());
        scanner.nextLine();
        System.out.print("Status: ");
        resid.setStatus(scanner.nextLine());
        System.out.print("Data de armazenamento: ");
        resid.setDataArmazenamento(scanner.nextLine());
        System.out.print("Área de geração do resíduo: ");
        resid.setAreaGeracaoDeResiduo(scanner.nextLine());
        System.out.print("Turno de geração do resíduo: ");
        resid.setTurnoDeGeracao(scanner.nextLine());

        String query = "INSERT INTO RESIDUOELETRONICO (acondicionamento,pesoKg,status,dataArmazenamento, areaGeracaoDeResiduo, turnoDeGeracao,nomeEquipamento, quantE)"
                + " VALUES ("
                + "'" + resid.getAcondicionamento() + "', "
                + "'" + resid.getPesoKg() + "', "
                + "'" + resid.getStatus() + "', "
                + "'" + resid.getDataArmazenamento() + "', "
                + "'" + resid.getAreaGeracaoDeResiduo() + "', "
                + "'" + resid.getTurnoDeGeracao() + "', "
                + "'" + resid.getNomeEquipamento() + "', "
               + resid.getQuantE()
               + ")";
        if (bd.insert(query)) {
            System.out.println(" Novo resíduo cadastrado com sucesso.");
        } else {
            System.out.println("Erro ao cadastrar.");
        }     
                break;
                
                
            case 2:
                
        ResiduoQuimico  residi = new ResiduoQuimico();
        
        System.out.print("Acondicionamento: ");
        residi.setAcondicionamento(scanner.nextLine());
        System.out.print("Peso em Kg: ");
        residi.setPesoKg(scanner.nextDouble());
        scanner.nextLine();
        System.out.print("Status: ");
        residi.setStatus(scanner.nextLine());
        System.out.print("Data de armazenamento: ");
        residi.setDataArmazenamento(scanner.nextLine());
        System.out.print("Área de geração do resíduo: ");
        residi.setAreaGeracaoDeResiduo(scanner.nextLine());
        System.out.print("Turno de geração do resíduo: ");
        residi.setTurnoDeGeracao(scanner.nextLine());
        System.out.print("Estado físico do resíduo: ");
        residi.setEstadoFisico(scanner.nextLine());
        System.out.println("");
        System.out.print("Digite o código da ONU: ");
        System.out.print("---------------------------------------------------------------------------------------------------------------------------------------------");
        System.out.print("1345 - BORRACHA, SOBRAS ou BORRACHA RESÍDUO, em pó ou em grãos de até 840 micra, contendo mais de 45% de borracha: ");
        System.out.print("1364 - ALGODÃO RESÍDUOS, OLEOSOS ou RESÍDUOS OLEOSOS DE ALGODÃO ou RESÍDUOS DE ALGODÃO, OLEOSOS: ");
        System.out.print("1387 - RESÍDUO DE LÃ, ÚMIDO ou MOLHADO: ");
        System.out.print("1857 - RESÍDUOS TÊXTEIS, ÚMIDOS: ");
        System.out.print("3291 - RESÍDUOS CLÍNICOS INESPECÍFICOS, N.E., ou RESÍDUOS (BIO) MÉDICOS, N.E., ou RESÍDUOS MÉDICOS REGULAMENTADOS, N.E.: ");
        System.out.print("3549 - RESÍDUOS MÉDICOS, CATEGORIA A, QUE AFETA SERES HUMANOS, sólido ou RESÍDUOS MÉDICOS, CATEGORIA A, QUE AFETA apenas ANIMAIS, sólido: ");
        System.out.print("3509 - EMBALAGENS VAZIAS, NÃO LIMPAS: ");
        System.out.print("1993 - RESÍDUO de Líquido Inflamável, N.E.: ");
        System.out.print("3077 - RESÍDUO DE SUBSTÂNCIA QUE APRESENTA RISCO PARA O MEIO AMBIENTE, SÓLIDA, N.E.: ");
        System.out.print("1993 - RESÍDUO de Líquido Inflamável, N.E: ");
        System.out.print("3077 - RESÍDUO DE SUBSTÂNCIA QUE APRESENTA RISCO PARA O MEIO AMBIENTE, SÓLIDA, N.E.: ");
        System.out.print("---------------------------------------------------------------------------------------------------------------------------------------------");
        residi.setCodigONU(scanner.nextInt());
        scanner.nextLine();
        
// verificar se dara problema na String --querys----
        String querys = "INSERT INTO RESIDUOQUIMICO (acondicionamento,pesoKg,status,dataArmazenamento, areaGeracaoDeResiduo, turnoDeGeracao,estadoFisico,codigONU)"
                + " VALUES ("
                + "'" + residi.getAcondicionamento() + "', "
                + "'" + residi.getPesoKg() + "', "
                + "'" + residi.getStatus() + "', "
                + "'" + residi.getDataArmazenamento() + "', "
                + "'" + residi.getAreaGeracaoDeResiduo() + "', "
                + "'" + residi.getTurnoDeGeracao() + "', "
                + "'" + residi.getEstadoFisico() + "', "
               + residi.getCodigONU()
               + ")";
        if (bd.insert(querys)) {
            System.out.println(" Novo resíduo cadastrado com sucesso.");
        } else {
            System.out.println("Erro ao cadastrar.");
        }
                 
                break;
}
        

    }


    public static void main(String[] args) {

        scanner = new Scanner(System.in);
        bd = new MySQL8/*( nomeDoBanco, usuario, senha
                
                );*/
        if (!bd.conectaBanco()) {
            System.exit(1);
        }
        int opcao;

        do {
            System.out.println();
            System.out.println("-------------- Cadastro de Resíduos --------------");
            System.out.println("");
            System.out.println("1. Listar Resíduos");
            System.out.println("2. Consultar Resíduos");
            System.out.println("3. Cadastrar Novo Resíduo");
            System.out.println("4. Sair");
            System.out.print("Escolha: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            System.out.println();

            switch (opcao) {
                case 1:
                    listarResiduo();
                    break;
                case 2:
                    consultarResiduo();
                    break;
                case 3:
                    cadastrarResiduo();
                    break;

                case 4:
                    System.out.println("Encerando...");
                    break;
                default:
                    System.out.println("Opcao invalida");
            }
        } while (opcao != 4);
        
        bd.fechaBanco();

    }
}

   
