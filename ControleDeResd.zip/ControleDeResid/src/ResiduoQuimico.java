/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */



/**
 *
 * @author SAMUEL
 */
public class ResiduoQuimico extends ControleDeResiduo {
  
    private String estadoFisico;
    private int codigONU; //codigo da ONU
    
   
    public ResiduoQuimico() {
        super();

    }

    public ResiduoQuimico (String acondicionamento,double pesoKg,String status,String dataArmazenamento, String areaGeracaoDeResiduo, String turnoDeGeracao,String estadoFisico, int codigONU) {
        super(acondicionamento, pesoKg, status, dataArmazenamento, areaGeracaoDeResiduo, turnoDeGeracao);
        
        this. estadoFisico = estadoFisico;
        this.codigONU = codigONU;
        
    }
    
    @Override
    public String toString() {
   
            return String.format("ID: = %d", id) + "\n"+
                   String.format("Acondicionamento: = %s", acondicionamento) + "\n"+
                   String.format("Peso em Kg: = %f", pesoKg) + "\n"+
                   String.format("Status: = %s", status) + "\n"+
                   String.format("Data de armazenamento:  = %s", dataArmazenamento) + "\n"+
                   String.format("Área de geração do resíduo: = %s", areaGeracaoDeResiduo) + "\n"+
                   String.format("Turno de geração:  = %s", turnoDeGeracao)+ "\n"+
                   String.format("Estado Físico do Resíduo: = %s", estadoFisico)+ "\n"+
                   String.format("Código da ONU: = %4d", codigONU);
        
              
    } 

    public String getEstadoFisico() {
        return estadoFisico;
    }

    public void setEstadoFisico(String estadoFisico) {
        this.estadoFisico = estadoFisico;
    }

    public int getCodigONU() {
        return codigONU;
    }

    public void setCodigONU(int codigONU) {
        this.codigONU = codigONU;
    }


    }
    
